package com.maven;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.mockito.Mockito.when;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.DisplayName;

import entidades.Apuesta;
import entidades.Carrera;
import entidades.Circuito;
import entidades.Equipo;
import entidades.Estado;
import entidades.Piloto;
import entidades.Tipo;
import entidades.TipoApuesta;
import entidades.Usuario;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.util.Random;

public class ApuestaTest {
	@Mock
	private Random randomMock;
	
    private Apuesta apuesta;
    private Piloto piloto;
    private Usuario usuario;
    private Carrera carrera;
    private TipoApuesta tipoApuesta;

    @BeforeEach
    void setUp() {
    	 MockitoAnnotations.openMocks(this);
         usuario = new Usuario("user1", "pass", "Ana", "López", 
            LocalDate.now(), "ana@test.com", "611223344", 1000.0, false);
         carrera = new Carrera("GP Mónaco", LocalDate.now(), 
            new Circuito("Circuito de Mónaco", "Mónaco", 3.337, 78));
         piloto = new Piloto("Charles", "Leclerc", 16, "Monegasco", 
            new Equipo("Ferrari", "Italia"));
         tipoApuesta= new TipoApuesta(Tipo.PODIO, "Apuesta a quién termina en podio" );

        apuesta = new Apuesta(
            usuario, carrera, piloto, 
            tipoApuesta, Estado.PENDIENTE, 500.0, 3.0, randomMock);
    }

    @Test
    @DisplayName("Getter y Setter para estado")
    void testEstado() {
        apuesta.setEstado(Estado.GANADA);
        assertEquals(Estado.GANADA, apuesta.getEstado());
    }
    
    @Test
    @DisplayName("Getter y Setter para piloto")
    void testPiloto() {
        apuesta.setPiloto(piloto);
        assertEquals(piloto, apuesta.getPiloto());
    }
    
    @Test
    @DisplayName("Getter y Setter para usuario")
    void testUsuario() {
        apuesta.setPropietario(usuario);
        assertEquals(usuario, apuesta.getPropietario());
    }
    @Test
    @DisplayName("Getter y Setter para carrera")
    void testCarrera() {
        apuesta.setCarrera(carrera);
        assertEquals(carrera, apuesta.getCarrera());
    }
    
    @Test
    @DisplayName("Getter y Setter para tipo de apuesta")
    void testTipoApuesta() {
        apuesta.setTipoApuesta(tipoApuesta);
        assertEquals(tipoApuesta, apuesta.getTipoApuesta());
    }
    
    @Test
    @DisplayName("Getter y Setter para cantidad apostada")
    void testCantidadApostada() {
        apuesta.setCantidadApostada(500);
        assertEquals(500, apuesta.getCantidadApostada());
    }
    
    @Test
    @DisplayName("Getter para ganancia potencial")
    void testGananciaPotencial() {
        double cantidadApostada=apuesta.getCantidadApostada();
        double cuota=apuesta.getCUOTA();
        double gananciaPotencial=cantidadApostada*cuota;
        assertEquals(gananciaPotencial, apuesta.getGananciaPotencial());
    }
    
    @Test
    @DisplayName("Getter para cuota")
    void testCuota() {
        
        assertEquals(3.0, apuesta.getCUOTA());
    }
    
    @Test
    void testSimularResultadoGanada() {
        // Simulamos que nextBoolean() devuelva 'true', es decir, la apuesta se ganó
        when(randomMock.nextBoolean()).thenReturn(true);

        // Ejecutamos el método simularResultado
        apuesta.simularResultado();

        // Comprobamos que el estado sea 'GANADA'
        assertEquals(Estado.GANADA, apuesta.getEstado());
    }

    @Test
    void testSimularResultadoPerdida() {
        // Simulamos que nextBoolean() devuelva 'false', es decir, la apuesta se perdió
        when(randomMock.nextBoolean()).thenReturn(false);

        // Ejecutamos el método simularResultado
        apuesta.simularResultado();

        // Comprobamos que el estado sea 'PERDIDA'
        assertEquals(Estado.PERDIDA, apuesta.getEstado());
    }

    @Test
    void testSimularResultadoNoPendiente() {
        // Cambiamos el estado a PERDIDA (no está en PENDIENTE)
        apuesta.simularResultado();  // Inicialmente debería ser pendiente
        apuesta.simularResultado();  // Esto no debería cambiar el estado porque ya no está pendiente

        // Comprobamos que el estado sigue siendo 'PERDIDA'
        assertEquals(Estado.PERDIDA, apuesta.getEstado());
    }

    @Test
    @DisplayName("Verificar que el método toString devuelve la información correcta")
    void testToString() {
        apuesta.setEstado(Estado.PENDIENTE);
        
        String expectedString = "Apuesta{propietario=" + usuario + 
            ", carrera=" + carrera + ", piloto=" + piloto + 
            ", tipoApuesta=" + tipoApuesta + ", estado=PENDIENTE" + 
            ", cantidadApostada=500.0, cuota=3.0}";
        
        assertEquals(expectedString, apuesta.toString());
    }
    
    
}