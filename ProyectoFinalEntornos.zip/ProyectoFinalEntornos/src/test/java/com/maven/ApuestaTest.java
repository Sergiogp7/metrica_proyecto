package com.maven;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import entidades.Apuesta;
import entidades.Carrera;
import entidades.Circuito;
import entidades.Equipo;
import entidades.Estado;
import entidades.Piloto;
import entidades.Tipo;
import entidades.TipoApuesta;
import entidades.Usuario;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;

public class ApuestaTest {

    private Apuesta apuesta;

    @BeforeEach
    void setUp() {
        Usuario usuario = new Usuario("user1", "pass", "Ana", "López", 
            LocalDate.now(), "ana@test.com", "611223344", 1000.0, false);
        Carrera carrera = new Carrera("GP Mónaco", LocalDate.now(), 
            new Circuito("Circuito de Mónaco", "Mónaco", 3.337, 78));
        Piloto piloto = new Piloto("Charles", "Leclerc", 16, "Monegasco", 
            new Equipo("Ferrari", "Italia"));

        apuesta = new Apuesta(
            usuario, carrera, piloto, 
            new TipoApuesta(Tipo.PODIO, "Apuesta por podio"), 
            Estado.PENDIENTE, 500.0, 3.0
        );
    }

    @Test
    @DisplayName("Getter y Setter para estado")
    void testEstado() {
        apuesta.setEstado(Estado.GANADA);
        assertEquals(Estado.GANADA, apuesta.getEstado());
    }
}