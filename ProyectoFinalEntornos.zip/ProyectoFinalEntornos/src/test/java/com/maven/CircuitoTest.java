package com.maven;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import entidades.Circuito;

import static org.junit.jupiter.api.Assertions.*;

public class CircuitoTest {

    private Circuito circuito;

    @BeforeEach
    void setUp() {
        circuito = new Circuito("Silverstone", "Reino Unido", 5.891, 52);
    }

    @Test
    @DisplayName("Getter y Setter para longitud")
    void testLongitud() {
        circuito.setLongitud(6.0);
        assertEquals(6.0, circuito.getLongitud());
    }
    
    @Test
    @DisplayName("Getter y Setter para nombre")
    void testNombre() {
        circuito.setNombre("Nurbur Ring");
        assertEquals("Nurbur Ring", circuito.getNombre());
    }
    
    @Test
    @DisplayName("Getter y Setter para localizacion")
    void testLocalizacion() {
        circuito.setLocalizacion("Alemania");
        assertEquals("Alemania", circuito.getLocalizacion());
    }
    
    @Test
    @DisplayName("Getter y Setter para el número de vueltas")
    void testNumVueltas() {
        circuito.setNumVueltas(68);
        assertEquals(68, circuito.getNumVueltas());
    }
    
    @Test
    @DisplayName("Verificar que el método toString devuelve la información correcta")
    void testToString() {
        
        String expectedString = circuito.getNombre() + " (" + circuito.getLocalizacion() +")"
        + ", con " + circuito.getLongitud() + " km de longitud y " + circuito.getNumVueltas() + " vueltas";
        
        assertEquals(expectedString, circuito.toString());
    }
    

    
}