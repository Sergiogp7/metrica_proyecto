package com.maven;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import entidades.Circuito;

import static org.junit.jupiter.api.Assertions.*;

public class CircuitoTest {

    private Circuito circuito;

    @BeforeEach
    void setUp() {
        circuito = new Circuito("Silverstone", "Reino Unido", 5.891, 52);
    }

    @Test
    @DisplayName("Getter y Setter para longitud")
    void testLongitud() {
        circuito.setLongitud(6.0);
        assertEquals(6.0, circuito.getLongitud());
    }

    @Test
    @DisplayName("Setter de longitud negativa no modifica el valor")
    void testLongitudNegativa() {
        circuito.setLongitud(-1.0);
        assertEquals(5.891, circuito.getLongitud());
    }
}