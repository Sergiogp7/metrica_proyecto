package com.maven;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import entidades.Carrera;
import entidades.Circuito;

import java.time.LocalDate;
import static org.junit.jupiter.api.Assertions.*;

public class CarreraTest {

    private Carrera carrera;
    private Circuito circuito;

    @BeforeEach
    void setUp() {
        circuito = new Circuito("Circuito de Barcelona", "España", 4.655, 66);
        carrera = new Carrera("GP España", LocalDate.of(2024, 6, 20), circuito);
    }

    @Test
    @DisplayName("Getter y Setter para fecha")
    void testFecha() {
        LocalDate nuevaFecha = LocalDate.of(2025, 6, 20);
        carrera.setFecha(nuevaFecha);
        assertEquals(nuevaFecha, carrera.getFecha());
    }

    @Test
    @DisplayName("Setter de fecha pasada no se aplica")
    void testFechaPasada() {
        LocalDate fechaPasada = LocalDate.of(2020, 1, 1);
        carrera.setFecha(fechaPasada);
        assertEquals(LocalDate.of(2024, 6, 20), carrera.getFecha());
    }
}
