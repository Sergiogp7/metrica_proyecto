package com.maven;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import entidades.Carrera;
import entidades.Circuito;
import entidades.Estado;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import static org.junit.jupiter.api.Assertions.*;

public class CarreraTest {

    private Carrera carrera,carrera2;
    private Circuito circuito,circuito2;

    @BeforeEach
    void setUp() {
        circuito = new Circuito("Circuito de Barcelona", "España", 4.655, 66);
        circuito2 = new Circuito("Circuito de Imola", "Italia", 3.51, 62);
        carrera = new Carrera("GP España", LocalDate.of(2024, 6, 20), circuito);
        carrera2 = new Carrera("GP Italia", LocalDate.of(2024, 7, 23), circuito2);

    }

    @Test
    @DisplayName("Getter y Setter para fecha")
    void testFecha() {
        LocalDate nuevaFecha = LocalDate.of(2025, 6, 20);
        carrera.setFecha(nuevaFecha);
        assertEquals(nuevaFecha, carrera.getFecha());
    }

    @Test
    @DisplayName("Setter de fecha pasada no se aplica")
    void testFechaPasada() {
        LocalDate fechaPasada = LocalDate.of(2020, 1, 1);
        carrera.setFecha(fechaPasada);
        assertEquals(fechaPasada, carrera.getFecha());
    }
    
    @Test
    @DisplayName("Getter y Setter para nombre del GP")
    void testNombreGranPremio() {
        carrera.setNombreGranPremio("GP Alemania");
        assertEquals("GP Alemania", carrera.getNombreGranPremio());
    }
    
    @Test
    @DisplayName("Getter y Setter para circuito")
    void testCircuito() {
        carrera.setCircuito(circuito);
        assertEquals(circuito, carrera.getCircuito());
    }
    
    @Test
    @DisplayName("Verificar que el método toString devuelve la información correcta")
    void testToString() {
        
        
        String expectedString = carrera.getNombreGranPremio() +" -> "+ circuito + " que se disputa el " 
                + carrera.getFecha().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
        
        assertEquals(expectedString, carrera.toString());
    }
    
    @Test
    void testCompareTo_SameNames() {
        // Cuando los nombres son iguales (ignora mayúsculas/minúsculas)
        assertEquals(0, carrera.compareTo(new Carrera("GP España",  LocalDate.of(2024, 6, 20), circuito)));
    }

    @Test
    void testCompareTo_LessThan() {
        // Comprobamos que "GP España" es alfabéticamente menor que "GP Italia"
        assertTrue(carrera.compareTo(carrera2) < 0);
    }

    @Test
    void testCompareTo_GreaterThan() {
        // Comprobamos que "GP Italia" es alfabéticamente mayor que "GP España"
        assertTrue(carrera2.compareTo(carrera) > 0);
    }


  
    
    

}
