package com.maven;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import entidades.Equipo;
import entidades.Piloto;

import static org.junit.jupiter.api.Assertions.*;

public class PilotoTest {

    private Piloto piloto;

    @BeforeEach
    void setUp() {
        Equipo equipo = new Equipo("Ferrari", "Italia");
        piloto = new Piloto("Charles", "Leclerc", 16, "Monegasco", equipo);
    }

    @Test
    @DisplayName("Getter y Setter para número")
    void testNumero() {
        piloto.setNumero(55);
        assertEquals(55, piloto.getNumero());
    }

    @Test
    @DisplayName("Setter de número inválido (fuera de rango 1-99)")
    void testNumeroInvalido() {
        piloto.setNumero(100);
        assertEquals(16, piloto.getNumero()); // Valor original no cambia
    }
}