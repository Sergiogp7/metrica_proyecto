package com.maven;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import entidades.Carrera;
import entidades.Equipo;
import entidades.Estado;
import entidades.Piloto;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class PilotoTest {

    private Piloto piloto,piloto2;
    private Equipo equipo,equipo2;
    @BeforeEach
    void setUp() {
         equipo = new Equipo("Ferrari", "Italia");
        piloto = new Piloto("Charles", "Leclerc", 16, "Monegasco", equipo);
        equipo2 = new Equipo("Red Bull", "Austria");
        piloto2 = new Piloto("Max", "Verstappen", 1, "Neerlandes", equipo2);
    }

    @Test
    @DisplayName("Getter y Setter para número")
    void testNumero() {
        piloto.setNumero(55);
        assertEquals(55, piloto.getNumero());
    }
    
    @Test
    @DisplayName("Getter y Setter para nombre")
    void testNombre() {
        piloto.setNombre("Carlos");
        assertEquals("Carlos", piloto.getNombre());
    }
    
    @Test
	@DisplayName("Debería lanzar una excepción si el nombre está vacío")
	void testNombrePilotoVacio() throws Exception{
		Exception exception = assertThrows(IllegalArgumentException.class, ()->{
            new Piloto("", "Leclerc", 16, "Monegasco", equipo); });
		String mensajeEsperado = "El nombre del piloto no puede estar vacio";
		assertEquals(mensajeEsperado, exception.getMessage());
	}
    
    @Test
    @DisplayName("Getter y Setter para apellido")
    void testApellido() {
        piloto.setApellido("Sainz");
        assertEquals("Sainz", piloto.getApellido());
    }
    
    @Test
    @DisplayName("Getter y Setter para nacionalidad")
    void testNacionalidad() {
        piloto.setNacionalidad("español");
        assertEquals("español", piloto.getNacionalidad());
    }
    
    @Test
    @DisplayName("Getter y Setter para equipo")
    void testEquipo() {
        piloto.setEquipo(equipo);
        assertEquals(equipo, piloto.getEquipo());
    }
    
    @Test
    @DisplayName("Verificar que el método toString devuelve la información correcta")
    void testToString() {
        
        String expectedString = " " +piloto.getNombre()+ " "  + piloto.getApellido() +" "
        		+ ""+ "("+piloto.getNumero()+")" +" , " + piloto.getNacionalidad() + " Equipo: "+ equipo.getNombre();
        
        assertEquals(expectedString, piloto.toString());
    }
    
    @Test
    void testCompareTo_SameNames() {
        assertEquals(0, piloto.compareTo(new Piloto("Charles", "Leclerc", 16, "Monegasco", equipo)));
    }

    @Test
    void testCompareTo_LessThan() {
        
        assertTrue(piloto.compareTo(piloto2) < 0);
    }

    @Test
    void testCompareTo_GreaterThan() {
        assertTrue(piloto2.compareTo(piloto) > 0);
    }
    
   

   
}