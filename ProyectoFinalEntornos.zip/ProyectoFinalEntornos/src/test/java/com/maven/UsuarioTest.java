package com.maven;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import entidades.Apuesta;
import entidades.Carrera;
import entidades.Circuito;
import entidades.Equipo;
import entidades.Estado;
import entidades.Piloto;
import entidades.Tipo;
import entidades.TipoApuesta;
import entidades.Usuario;

import java.time.LocalDate;
import static org.junit.jupiter.api.Assertions.*;

public class UsuarioTest {

    private Usuario usuario;

    @BeforeEach
    void setUp() {
        usuario = new Usuario(
            "clara2024",
            "password123",
            "Clara",
            "García",
            LocalDate.of(1990, 5, 15),
            "clara@example.com",
            "600112233",
            500.0,
            false
        );
    }

    @Test
    @DisplayName("Recarga de saldo válida actualiza correctamente el saldo")
    void recargarSaldoValido() {
        double nuevoSaldo = usuario.recargarSaldo(300.0);
        assertEquals(800.0, nuevoSaldo);
    }

    @Test
    @DisplayName("Recarga de saldo negativo no modifica el saldo")
    void recargarSaldoNegativo() {
        double nuevoSaldo = usuario.recargarSaldo(-100.0);
        assertEquals(500.0, nuevoSaldo);
    }

    @Test
    @DisplayName("Añadir apuesta con saldo suficiente reduce el saldo")
    void anadirApuestaSaldoSuficiente() {
        Carrera carrera = new Carrera("GP España", LocalDate.now(), new Circuito("Circuito", "Barcelona", 5.0, 66));
        Apuesta apuesta = new Apuesta(usuario, carrera, new Piloto("Lewis", "Hamilton", 44, "Británico", new Equipo("Mercedes", "Alemania")), 
            new TipoApuesta(Tipo.GANADOR, "Apuesta por ganador"), Estado.PENDIENTE, 200.0, 2.5);

        assertDoesNotThrow(() -> usuario.añadirApuesta(apuesta));
        assertEquals(300.0, usuario.getSaldo());
    }

    @Test
    @DisplayName("Añadir apuesta con saldo insuficiente lanza excepción")
    void anadirApuestaSaldoInsuficiente() {
        Carrera carrera = new Carrera("GP España", LocalDate.now(), new Circuito("Circuito", "Barcelona", 5.0, 66));
        Apuesta apuesta = new Apuesta(usuario, carrera, new Piloto("Lewis", "Hamilton", 44, "Británico", new Equipo("Mercedes", "Alemania")), 
            new TipoApuesta(Tipo.GANADOR, "Apuesta por ganador"), Estado.PENDIENTE, 600.0, 2.5);

        assertThrows(IllegalArgumentException.class, () -> usuario.añadirApuesta(apuesta));
    }
}