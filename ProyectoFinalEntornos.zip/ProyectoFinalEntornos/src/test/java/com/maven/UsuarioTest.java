package com.maven;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import entidades.Apuesta;
import entidades.Carrera;
import entidades.Circuito;
import entidades.Equipo;
import entidades.Estado;
import entidades.Piloto;
import entidades.Tipo;
import entidades.TipoApuesta;
import entidades.Usuario;

import java.time.LocalDate;
import static org.junit.jupiter.api.Assertions.*;

public class UsuarioTest {

    private Usuario usuario,usuario2;

    @BeforeEach
    void setUp() {
        usuario = new Usuario(
            "clara2024",
            "password123",
            "Clara",
            "García",
            LocalDate.of(1990, 5, 15),
            "clara@example.com",
            "600112233",
            500.0,
            false
        );
      
    }

    @Test
    @DisplayName("Recarga de saldo válida actualiza correctamente el saldo")
    void recargarSaldoValido() {
        double nuevoSaldo = usuario.recargarSaldo(300.0);
        assertEquals(800.0, nuevoSaldo);
    }

    @Test
    @DisplayName("Recarga de saldo negativo no modifica el saldo")
    void recargarSaldoNegativo() {
        double nuevoSaldo = usuario.recargarSaldo(-100.0);
        assertEquals(500.0, nuevoSaldo);
    }

    @Test
    @DisplayName("Añadir apuesta con saldo suficiente reduce el saldo")
    void anadirApuestaSaldoSuficiente() {
        Carrera carrera = new Carrera("GP España", LocalDate.now(), new Circuito("Circuito", "Barcelona", 5.0, 66));
        Apuesta apuesta = new Apuesta(usuario, carrera, new Piloto("Lewis", "Hamilton", 44, "Británico", new Equipo("Mercedes", "Alemania")), 
            new TipoApuesta(Tipo.GANADOR, "Apuesta por ganador"), Estado.PENDIENTE, 200.0, 2.5, null);

        assertDoesNotThrow(() -> usuario.añadirApuesta(apuesta));
        assertEquals(300.0, usuario.getSaldo());
    }

    @Test
    @DisplayName("Añadir apuesta con saldo insuficiente lanza excepción")
    void anadirApuestaSaldoInsuficiente() {
        Carrera carrera = new Carrera("GP España", LocalDate.now(), new Circuito("Circuito", "Barcelona", 5.0, 66));
        Apuesta apuesta = new Apuesta(usuario, carrera, new Piloto("Lewis", "Hamilton", 44, "Británico", new Equipo("Mercedes", "Alemania")), 
            new TipoApuesta(Tipo.GANADOR, "Apuesta por ganador"), Estado.PENDIENTE, 600.0, 2.5, null);

        assertThrows(IllegalArgumentException.class, () -> usuario.añadirApuesta(apuesta));
    }
    
    @Test
    @DisplayName("getCorreo() devuelve el correo correcto")
    void testGetCorreo() {
        assertEquals("clara@example.com", usuario.getCorreo());
    }

    @Test
    @DisplayName("getTelefono() devuelve el teléfono correcto")
    void testGetTelefono() {
        assertEquals("600112233", usuario.getTelefono());
    }

    @Test
    @DisplayName("getSaldo() devuelve el saldo correcto")
    void testGetSaldo() {
        assertEquals(500.0, usuario.getSaldo());
    }

    @Test
    @DisplayName("esAdmin() devuelve el estado correcto")
    void testEsAdmin() {
        assertFalse(usuario.esAdmin());
    }

    @Test
    @DisplayName("getApuestas() devuelve una lista vacía inicialmente")
    void testGetApuestasInicial() {
        assertTrue(usuario.getApuestas().isEmpty());
    }

    @Test
    @DisplayName("setNombreUsuario() actualiza correctamente")
    void testSetNombreUsuario() {
        usuario.setnombreUsuario("nuevoUsuario");
        assertEquals("nuevoUsuario", usuario.getnombreUsuario());
    }

    @Test
    @DisplayName("setPassword() actualiza correctamente")
    void testSetPassword() {
        usuario.setPassword("nuevaPassword");
        assertEquals("nuevaPassword", usuario.getPassword());
    }

    @Test
    @DisplayName("setNombre() actualiza correctamente")
    void testSetNombre() {
        usuario.setNombre("Ana");
        assertEquals("Ana", usuario.getNombre());
    }

    @Test
    @DisplayName("setApellidos() actualiza correctamente")
    void testSetApellidos() {
        usuario.setApellidos("López");
        assertEquals("López", usuario.getApellidos());
    }

    @Test
    @DisplayName("setFechaNac() actualiza fecha válida")
    void testSetFechaNacValida() {
        LocalDate nuevaFecha = LocalDate.of(2000, 1, 1);
        usuario.setFechaNac(nuevaFecha);
        assertEquals(nuevaFecha, usuario.getFechaNac());
    }

    
    @Test
    @DisplayName("setCorreo() actualiza correo válido")
    void testSetCorreoValido() {
        usuario.setCorreo("nuevo@example.com");
        assertEquals("nuevo@example.com", usuario.getCorreo());
    }


    @Test
    @DisplayName("setTelefono() actualiza teléfono válido")
    void testSetTelefonoValido() {
        usuario.setTelefono("611223344");
        assertEquals("611223344", usuario.getTelefono());
    }

   

    @Test
    @DisplayName("setSaldo() actualiza saldo positivo")
    void testSetSaldoPositivo() {
        usuario.setSaldo(1000.0);
        assertEquals(1000.0, usuario.getSaldo());
    }

    @Test
    @DisplayName("setEsAdmin() actualiza el estado")
    void testSetEsAdmin() {
        usuario.setEsAdmin(true);
        assertTrue(usuario.esAdmin());
    }

    @Test
    @DisplayName("añadirApuesta() reduce el saldo correctamente")
    void testAnadirApuesta() {
        Carrera carrera = new Carrera("GP España", LocalDate.now(), 
            new Circuito("Barcelona", "España", 4.6, 66));
        Apuesta apuesta = new Apuesta(
            usuario, carrera, 
            new Piloto("Carlos", "Sainz", 55, "Español", new Equipo("Ferrari", "Italia")),
            new TipoApuesta(Tipo.GANADOR, "Ganador"), 
            Estado.PENDIENTE, 200.0, 2.0, null
        );
        
        usuario.añadirApuesta(apuesta);
        assertEquals(300.0, usuario.getSaldo());
        assertEquals(1, usuario.getApuestas().size());
    }
    
    @Test
    @DisplayName("Verificar que el método toString devuelve la información correcta")
    void testToString() {
        
        String expectedString = usuario.getNombre() + " " + usuario.getApellidos();
        
        assertEquals(expectedString, usuario.toString());
    } 

    

    @Test
    @DisplayName("compareTo() ordena por nombre")
    void testCompareTo() {
        Usuario usuarioA = new Usuario("usuarioA", "pass", "Ana", "López", 
            LocalDate.now(), "ana@test.com", "611223344", 100.0, false);
        Usuario usuarioB = new Usuario("usuarioB", "pass", "Berta", "Martínez", 
            LocalDate.now(), "berta@test.com", "622334455", 200.0, false);
        assertTrue(usuarioA.compareTo(usuarioB) < 0);
        assertFalse(usuarioB.compareTo(usuarioA) < 0);

    }
}