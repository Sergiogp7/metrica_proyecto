/*
 * Clase Carrera
 */
package entidades;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author clara
 */
public class Carrera implements Comparable<Carrera>  {

    private String nombreGranPremio;
    private LocalDate fecha;
    private Circuito circuito;

    public Carrera(String nombreGranPremio, LocalDate fecha, Circuito circuito) {
        this.nombreGranPremio = nombreGranPremio;
        this.fecha = fecha;
        this.circuito = circuito;
    }

    public String getNombreGranPremio() {
        return nombreGranPremio;
    }

    public void setNombreGranPremio(String nombreGranPremio) {
        this.nombreGranPremio = nombreGranPremio;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public Circuito getCircuito() {
        return circuito;
    }

    public void setCircuito(Circuito circuito) {
        this.circuito = circuito;
    }
    
    @Override
    public String toString() {
        return nombreGranPremio +" -> "+ circuito + " que se disputa el " 
                + fecha.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
    }

    @Override
    public int compareTo(Carrera o) {
        return this.nombreGranPremio.compareToIgnoreCase(o.nombreGranPremio);
    }
    
   

}
