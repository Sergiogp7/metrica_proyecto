/*
 * Clase Apuesta
 */
package entidades;

import java.util.Random;

/**
 *
 * @author clara
 */
public class Apuesta {

    private Usuario propietario;
    private Carrera carrera;
    private Piloto piloto;
    private TipoApuesta tipoApuesta;
    private Estado estado;
    private double cantidadApostada;
    private final double CUOTA;
    private Random random;

    public Apuesta(Usuario propietario, Carrera carrera, Piloto piloto,
            TipoApuesta tipoApuesta, Estado estado, double cantidadApostada, double CUOTA, Random random) {
        this.propietario = propietario;
        this.carrera = carrera;
        this.piloto = piloto;
        this.tipoApuesta = tipoApuesta;
        this.estado = estado;
        this.cantidadApostada = cantidadApostada;
        this.CUOTA = CUOTA;
        this.random=random;

    }

    public Usuario getPropietario() {
        return propietario;
    }

    public void setPropietario(Usuario propietario) {
        this.propietario = propietario;
    }

    public Carrera getCarrera() {
        return carrera;
    }

    public void setCarrera(Carrera carrera) {
        this.carrera = carrera;
    }

    public Piloto getPiloto() {
        return piloto;
    }

    public void setPiloto(Piloto piloto) {
        this.piloto = piloto;
    }

    public TipoApuesta getTipoApuesta() {
        return tipoApuesta;
    }

    public void setTipoApuesta(TipoApuesta tipoApuesta) {
        this.tipoApuesta = tipoApuesta;
    }

    public Estado getEstado() {
        return estado;
    }

    public void setEstado(Estado estado) {
        this.estado = estado;
    }

    public double getCantidadApostada() {
        return cantidadApostada;
    }

    public void setCantidadApostada(double cantidadApostada) {
        this.cantidadApostada = cantidadApostada;
    }

    public double getGananciaPotencial() {
        return cantidadApostada * CUOTA;
    }
     public double getCUOTA() {
        return CUOTA;
    }

     public void simularResultado() {
         if (this.estado != Estado.PENDIENTE) {
             return;  // Si ya no está pendiente, no hacemos nada
         }
         
         boolean gano = random.nextBoolean();  // Usamos el Random inyectado

         if (gano) {
             this.estado = Estado.GANADA;
         } else {
             this.estado = Estado.PERDIDA;
         }
     }

    @Override
    public String toString() {
        return "Apuesta{" + "propietario=" + propietario + ", carrera=" + carrera + ", piloto=" + piloto + ", tipoApuesta=" + tipoApuesta + ", estado="
                + estado + ", cantidadApostada=" + cantidadApostada + ", cuota=" + CUOTA + '}';
    }

   

}
