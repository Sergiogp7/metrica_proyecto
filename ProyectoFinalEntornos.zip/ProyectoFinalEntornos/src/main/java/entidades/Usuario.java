/*
 * Clase Usuario
 */
package entidades;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 *
 * @author clara
 */
public class Usuario implements Comparable<Usuario> {

    private String nombreUsuario, password, nombre, apellidos, correo,telefono;
    private LocalDate fechaNac;
    private double saldo;
    private List<Apuesta> apuestas;
    private boolean esAdmin;

    public Usuario(String nombreUsuario, String password,
            String nombre, String apellidos,LocalDate fechaNac,
            String correo,String telefono, double saldo, boolean esAdmin) {
        this.nombreUsuario = nombreUsuario;
        this.password = password;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.fechaNac=fechaNac;
        this.correo = correo;
        this.telefono=telefono;
        this.saldo = saldo;
        this.esAdmin=esAdmin;
        this.apuestas=new ArrayList();

    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public LocalDate getFechaNac() {
        return fechaNac;
    }

    public void setFechaNac(LocalDate fechaNac) {
        this.fechaNac = fechaNac;
    }

    
    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public String getnombreUsuario() {
        return nombreUsuario;
    }

    public void setnombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public boolean esAdmin() {
        return esAdmin;
    }

    public void setEsAdmin(boolean esAdmin) {
        this.esAdmin = esAdmin;
    }

    public void añadirApuesta(Apuesta a) {
        if (a.getCantidadApostada() <= saldo) {
            apuestas.add(a);
            saldo -= a.getCantidadApostada();
            System.out.println("Apuesta realizada correctamente");
        } else {
            throw new IllegalArgumentException("Saldo insuficiente para realizar la apuesta");
        }
    }

    public double recargarSaldo(double cantidad) {
        if (cantidad < 0) {
            System.out.println("Error: no se puede recargar un saldo negativo.");
            return saldo; 
        }
        return saldo += cantidad;
    }

    public List<Apuesta> getApuestas() {
        return apuestas;
    }

    @Override
    public String toString() {
        return  nombre + " " + apellidos ;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 89 * hash + Objects.hashCode(this.nombreUsuario);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Usuario other = (Usuario) obj;
        return Objects.equals(this.nombreUsuario, other.nombreUsuario);
    }

    @Override
    public int compareTo(Usuario u) {
        return this.nombre.compareToIgnoreCase(u.nombre);
    }

}
