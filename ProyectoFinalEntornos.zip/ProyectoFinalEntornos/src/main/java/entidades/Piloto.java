/*
 * Clase Piloto
 */
package entidades;


/**
 *
 * @author clara
 */
public class Piloto implements Comparable<Piloto> {
    private String nombre, apellido;
    private String nacionalidad;
    private int numero;
    private Equipo equipo;

    public Piloto(String nombre, String apellido, int numero, String nacionalidad, Equipo equipo) {
        if (nombre.isEmpty()) {
            throw new IllegalArgumentException("El nombre del piloto no puede estar vacio");
        } else {
            this.nombre = nombre;
        }
        this.apellido = apellido;
        this.numero = numero;
        this.nacionalidad = nacionalidad;
        this.equipo = null;
        this.equipo=equipo;

    }


    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public String getNacionalidad() {
        return nacionalidad;
    }

    public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public void setNacionalidad(String nacionalidad) {
        this.nacionalidad = nacionalidad;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public Equipo getEquipo() {
        return equipo;
    }

    public void setEquipo(Equipo equipo) {
        this.equipo = equipo;
    }

    @Override
    public String toString() {
        return " " +nombre+ " "  + apellido +" "+ "("+numero+")" +" , " + nacionalidad + " Equipo: "+ equipo.getNombre();
    }

    @Override
    public int compareTo(Piloto o) {
        return this.nombre.compareToIgnoreCase(o.nombre);
    }

}
