/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyectoprogramacion;

import entidades.Carrera;
import entidades.Circuito;
import entidades.Equipo;
import entidades.Piloto;
import java.time.LocalDate;
import java.time.Month;

/**
 *
 * @author clara
 */
public class ProyectoProgramacion {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Equipo e = new Equipo("Mercedes", "Alemania");
        Equipo e3 = new Equipo("Ferrari", "Italia");
        Equipo e2 = new Equipo("Williams Racing", "Reino Unido");
        Piloto p = new Piloto("Charles", "Leclerc", 16, "Monegasco", e3);
        Piloto p2 = new Piloto("Lewis", "Hamilton", 44, "Ingl�s", e3);
        Piloto p3 = new Piloto("Carlos", "Sainz", 55, "Espa�ol", e2);
        Piloto p4 = new Piloto("Alexander", "Albon", 31, "Tailand�s", e2);
        Circuito ci = new Circuito("Pedro ximenez", "Barcelona", 134, 123);
        Carrera c = new Carrera("GP Espa�a", LocalDate.of(2025, Month.MARCH, 27), ci);

        e.insertarPiloto(p);
        e.insertarPiloto(p2);
        System.out.println(e);
        e2.insertarPiloto(p3);
        e2.insertarPiloto(p4);
        System.out.println(e2);
        System.out.println(c);
    }

}
