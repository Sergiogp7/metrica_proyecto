/*
 * author: clara
 * Clase para obtener datos de la tabla de apuestas de la base de datos
 */
package datos;

import entidades.Apuesta;
import entidades.Carrera;
import entidades.Circuito;
import entidades.Equipo;
import entidades.Estado;
import entidades.Piloto;
import entidades.Tipo;
import entidades.TipoApuesta;
import entidades.Usuario;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author clara
 */
public class DAOApuesta {

    public void insertarApuesta(Apuesta a, Usuario u) throws SQLException {
        Connection conn = null;
        int idUsuPropietario = obtenerIdPorNombre("usuario", "nombreusuario", u.getnombreUsuario(), "id_usuario");
        int idCarrera = obtenerIdPorNombre("carrera", "nombregranpremio", a.getCarrera().getNombreGranPremio(), "id_carrera");
        int idTipo = obtenerIdPorNombre("tipoapuesta", "tipo", String.valueOf(a.getTipoApuesta().getTipo()), "id_tipoapuesta");
        int idPiloto = obtenerIdPorNombre("piloto", "nombre", a.getPiloto().getNombre(), "id_piloto");
        try {
            conn = ConexionBD.conectarBD();
            PreparedStatement pst = conn.prepareStatement("insert into apuesta(PROPIETARIO_ID, CARRERA_ID, "
                    + "TIPOAPUESTA_ID, ESTADO, CANTIDADAPOSTADA, CUOTA, PILOTO_ID)"
                    + " values(?, ?, ?, ?, ?, ?, ?)");
            pst.setInt(1, idUsuPropietario);
            pst.setInt(2, idCarrera);
            pst.setInt(3, idTipo);
            pst.setString(4, String.valueOf(a.getEstado()));
            pst.setDouble(5, a.getCantidadApostada());
            pst.setDouble(6, a.getCUOTA());
            pst.setInt(7, idPiloto);

            pst.executeUpdate();

        } catch (SQLException e) {
            System.err.println("insertarUsuario: " + e.getMessage());
        } finally {
            ConexionBD.desconetarBD(conn);
        }
    }

    public Carrera buscarPornombreCarrera(String nombregranpremio) {
        Carrera c = null;
        Connection conn = null;
        try {
            conn = ConexionBD.conectarBD();
            String sql = ("select carrera.NOMBREGRANPREMIO, carrera.FECHA, circuito.nombre, circuito.localizacion, circuito.longitud, circuito.num_Vueltas"
                    + " from carrera JOIN circuito ON carrera.circuito_id = circuito.id_circuito where lower(carrera.NOMBREGRANPREMIO)= lower(?)");
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, nombregranpremio);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {

                String nombreCircuito = rs.getString("NOMBRE");
                String localizacion = rs.getString("LOCALIZACION");
                double longitud = rs.getDouble("LONGITUD");
                int numVueltas = rs.getInt("num_vueltas");
                Circuito circuito = new Circuito(nombreCircuito, localizacion, longitud, numVueltas);

                c = new Carrera(nombregranpremio, rs.getDate("fecha").toLocalDate(), circuito);

            }

        } catch (SQLException e) {
            System.err.println("buscarPornombreUsuario: " + e.getMessage());
        } finally {
            ConexionBD.desconetarBD(conn);
        }
        return c;
    }

    public TipoApuesta buscarPornombreTipoApuesta(String tipo) {
        TipoApuesta t = null;
        Connection conn = null;
        try {
            conn = ConexionBD.conectarBD();
            String sql = ("select * from tipoapuesta where lower(tipo)= lower(?)");
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, tipo);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                String tipoString = rs.getString("tipo");
                Tipo type = Tipo.valueOf(tipoString);
                t = new TipoApuesta(type, rs.getString("descripcion"));

            }

        } catch (SQLException e) {
            System.err.println("buscarPornombreUsuario: " + e.getMessage());
        } finally {
            ConexionBD.desconetarBD(conn);
        }
        return t;
    }

    public int obtenerIdPorNombre(String tabla, String campoNombre, String valor, String campoId) throws SQLException {
        Connection conn = null;
        String sql = "SELECT " + campoId + " FROM " + tabla + " WHERE " + campoNombre + " = ?";
        try {
            conn = ConexionBD.conectarBD();
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, valor);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                } else {
                    throw new SQLException("No se encontr� en " + tabla + " el valor: " + valor);
                }
            }
        } finally {
            ConexionBD.desconetarBD(conn);
        }
    }

    public Piloto buscarPorNombrePiloto(String nombre) {
        Piloto p = null;
        Connection conn = null;
        try {
            conn = ConexionBD.conectarBD();
            String sql = ("select piloto.nombre, piloto.apellido, piloto.numero, piloto.nacionalidad, equipo.nombre AS equipo_nombre , equipo.pais"
                    + " from piloto join equipo on piloto.equipo_id=equipo.id_equipo "
                    + "where lower(piloto.nombre)= lower(?)");
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, nombre);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                String nombreEquipo = rs.getString("equipo_nombre");
                Equipo equipo = new Equipo(nombreEquipo, rs.getString("pais"));
                p = new Piloto(nombre, rs.getString("apellido"),
                        rs.getInt("numero"), rs.getString("nacionalidad"), equipo);

            }

        } catch (SQLException e) {
            System.err.println("buscarPornombreUsuario: " + e.getMessage());
        } finally {
            ConexionBD.desconetarBD(conn);
        }
        return p;
    }

    public List<Apuesta> obtenerTodasLasApuestas(Usuario u) throws SQLException {
        Connection conn = null;
        List<Apuesta> apuestas = new ArrayList<>();
        int idUsuPropietario = obtenerIdPorNombre("usuario", "nombreusuario", u.getnombreUsuario(), "id_usuario");

        String sql = "SELECT "
                + "usuario.nombreusuario AS nombre_usuario, "
                + "carrera.nombregranpremio AS nombre_carrera, "
                + "tipoApuesta.tipo AS tipo_apuesta, "
                + "piloto.nombre AS nombre_piloto, "
                + "apuesta.estado, "
                + "apuesta.cantidadapostada, "
                + "apuesta.cuota "
                + "FROM apuesta "
                + "JOIN usuario ON apuesta.propietario_id = usuario.id_usuario "
                + "JOIN piloto ON apuesta.piloto_id = piloto.id_piloto "
                + "JOIN carrera ON apuesta.carrera_id = carrera.id_carrera "
                + "JOIN tipoApuesta ON apuesta.tipoapuesta_id = tipoApuesta.id_tipoapuesta "
                + "WHERE usuario.id_usuario = ?";

        try {
            conn = ConexionBD.conectarBD();
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setInt(1, idUsuPropietario);  
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                String nombreCarrera = rs.getString("nombre_carrera");
                String nombrePiloto = rs.getString("nombre_piloto");
                String tipoApuestaStr = rs.getString("tipo_apuesta");
                String estadoStr = rs.getString("estado");
                double cantidadApostada = rs.getDouble("cantidadapostada");
                double cuota = rs.getDouble("cuota");
                Carrera carrera = buscarPornombreCarrera(nombreCarrera);
                Piloto piloto = buscarPorNombrePiloto(nombrePiloto);   // te falta este m�todo, deber�as implementarlo
                TipoApuesta tipoApuesta = buscarPornombreTipoApuesta(tipoApuestaStr);
                Estado estado = Estado.valueOf(estadoStr);

                Apuesta apuesta = new Apuesta(u, carrera, piloto, tipoApuesta, estado, cantidadApostada, cuota, null);

                apuestas.add(apuesta);
            }
        } catch (SQLException e) {
            System.err.println("Obtener las apuestas: " + e.getMessage());
        } finally {
            ConexionBD.desconetarBD(conn);
        }
        return apuestas;
    }

}
