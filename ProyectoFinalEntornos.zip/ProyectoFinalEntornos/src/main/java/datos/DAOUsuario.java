/*
 * author: clara
 * Clase para obtener datos de la tabla de usuarios de la base de datos
 */
package datos;

import entidades.Usuario;
import java.util.List;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author clara
 */
public class DAOUsuario {

    public Usuario buscarPornombreUsuario(String nombreUsuario) {
        Usuario u = null;
        Connection conn = null;
        try {
            conn = ConexionBD.conectarBD();
            PreparedStatement pst = conn.prepareStatement("select * from usuario where nombreUsuario = ?");
            pst.setString(1, nombreUsuario);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                u = new Usuario(nombreUsuario, rs.getString("password"), rs.getString("nombre"),
                        rs.getString("apellidos"), rs.getDate("fechanacimiento").toLocalDate(),
                        rs.getString("correo"), rs.getString("telefono"),
                        rs.getDouble("saldo"), rs.getBoolean("esAdmin"));
            }
        } catch (SQLException e) {
            System.err.println("buscarPornombreUsuario: " + e.getMessage());
        } finally {
            ConexionBD.desconetarBD(conn);
        }
        return u;
    }

    public boolean insertarUsuario(Usuario u) {
        Connection conn = null;
        try {
            conn = ConexionBD.conectarBD();
            PreparedStatement pst = conn.prepareStatement("insert into usuario(nombreusuario, password, "
                    + "nombre, apellidos, fechanacimiento, correo, telefono,esadmin)"
                    + " values(?, ?, ?, ?, ?, ?, ?,?)");
            pst.setString(1, u.getnombreUsuario());
            pst.setString(2, u.getPassword());
            pst.setString(3, u.getNombre());
            pst.setString(4, u.getApellidos());
            pst.setDate(5, Date.valueOf(u.getFechaNac()));
            pst.setString(6, u.getCorreo());
            pst.setString(7, u.getTelefono());
            pst.setBoolean(8, u.esAdmin());

            int filas = pst.executeUpdate();
            return filas > 0;

        } catch (SQLException e) {
            System.err.println("insertarUsuario: " + e.getMessage());
            return false;
        } finally {
            ConexionBD.desconetarBD(conn);
        }
    }

    public List<Usuario> consultarUsuarios() {
        Connection conn = null;
        List<Usuario> usuarios = new ArrayList();
        try {
            conn = ConexionBD.conectarBD();
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("select * from usuario");
            while (rs.next()) {
                Usuario u = new Usuario(rs.getString("nombreUsuario"),
                        rs.getString("password"), rs.getString("nombre"),
                        rs.getString("apellidos"), rs.getDate("fechanacimiento").toLocalDate(),
                        rs.getString("correo"), rs.getString("telefono"),
                        rs.getDouble("saldo"), rs.getBoolean("esadmin"));

                usuarios.add(u);
            }
        } catch (SQLException e) {
            System.err.println("consultarUsuarios: " + e.getMessage());
        } finally {
            ConexionBD.desconetarBD(conn);
        }
        return usuarios;
    }

    public boolean actualizarSaldo(Usuario usuario) {
        Connection conn = null;
        String sql = "UPDATE usuario SET saldo = ? where nombreusuario = ? and password= ?";
        try {
            conn = ConexionBD.conectarBD();
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setDouble(1, usuario.getSaldo());
            stmt.setString(2, usuario.getnombreUsuario());
            stmt.setString(3, usuario.getPassword());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }

    }

    public boolean eliminarUsuarioPorNombre(String nombreUsuario) {
        Usuario u = null;
        boolean eliminado = false;
        Connection conn = null;
        try {
            conn = ConexionBD.conectarBD();
            PreparedStatement pst = conn.prepareStatement("delete from usuario where nombreUsuario = ?");
            pst.setString(1, nombreUsuario);

            int filasAfectadas = pst.executeUpdate();
            if (filasAfectadas > 0) {
                eliminado = true;
            }

        } catch (SQLException e) {
            System.err.println("eliminarUsuarioPorNombre: " + e.getMessage());
            if (conn != null) {
                try {
                    conn.rollback(); 
                } catch (SQLException ex) {
                    System.err.println("Error al hacer rollback: " + ex.getMessage());
                }
            }
        } finally {
            ConexionBD.desconetarBD(conn);
        }
        return eliminado;
    }

}
