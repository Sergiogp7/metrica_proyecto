/*
 * author: clara
 * Clase para obtener datos de la tabla de pilotos de la base de datos
 */
package datos;

import entidades.Equipo;
import entidades.Piloto;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author clara
 */
public class DAOPilotos {

    public List<Piloto> obtenerTodosLosPilotos() {
        List<Piloto> pilotos = new ArrayList<>();

        String sql = "select piloto.nombre, piloto.apellido, piloto.numero, piloto.nacionalidad, equipo.nombre AS equipo_nombre, equipo.pais from piloto "
                + "join equipo on piloto.equipo_id=equipo.id_equipo";
        try (Connection conn = DriverManager.getConnection(
                "jdbc:oracle:thin:@localhost:1521/xe", "formula1", "formula1"); Statement statement = conn.createStatement()) {
            ResultSet resultSet = statement.executeQuery(sql);
            while (resultSet.next()) {
                String nombrePiloto = resultSet.getString("nombre");
                String apellido = resultSet.getString("apellido");
                int numero = resultSet.getInt("numero");
                String nacionalidad = resultSet.getString("nacionalidad");
                String nombreEquipo = resultSet.getString("equipo_nombre");
                Equipo equipo = new Equipo(nombreEquipo, resultSet.getString("pais"));
                pilotos.add(new Piloto(nombrePiloto, apellido, numero, nacionalidad, equipo));

            }

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return pilotos;
    }

    public Piloto buscarPorNombrePiloto(String nombre) { //Cambiar
        Piloto p = null;
        Connection conn = null;
        try {
            conn = ConexionBD.conectarBD();
            String sql = ("select piloto.nombre, piloto.apellido, piloto.numero, piloto.nacionalidad, equipo.nombre AS equipo_nombre , equipo.pais"
                    + " from piloto join equipo on piloto.equipo_id=equipo.id_equipo "
                    + "where lower(piloto.nombre)= lower(?)");
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, nombre);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                String nombreEquipo = rs.getString("equipo_nombre");
                Equipo equipo = new Equipo(nombreEquipo, rs.getString("pais"));
                p = new Piloto(nombre, rs.getString("apellido"),
                        rs.getInt("numero"), rs.getString("nacionalidad"), equipo);

            }

        } catch (SQLException e) {
            System.err.println("buscarPornombreUsuario: " + e.getMessage());
        } finally {
            ConexionBD.desconetarBD(conn);
        }
        return p;
    }

}
