/*
 * Clase Circuito
 */
package entidades;

/**
 *
 * @author clara
 */
public class Circuito {
   private String nombre;
   private String localizacion;
   private double longitud;
   private int numVueltas;

    public Circuito(String nombre, String localizacion, double longitud, int numVueltas) {
        this.nombre = nombre;
        this.localizacion = localizacion;
        this.longitud = longitud;
        this.numVueltas = numVueltas;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getLocalizacion() {
        return localizacion;
    }

    public void setLocalizacion(String localizacion) {
        this.localizacion = localizacion;
    }

    public double getLongitud() {
        return longitud;
    }

    public void setLongitud(double longitud) {
        this.longitud = longitud;
    }

    public int getNumVueltas() {
        return numVueltas;
    }

    public void setNumVueltas(int numVueltas) {
        this.numVueltas = numVueltas;
    }

    @Override
    public String toString() {
        return nombre + " (" + localizacion +")"+ ", con " + longitud + " km de longitud y " + numVueltas + " vueltas";
    }
   
   
}
