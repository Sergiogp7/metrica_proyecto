/*
 Clase Factura
 */
package entidades;

import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author clara
 */
public class Factura  {

    private List<Apuesta> apuestas;
    private LocalDate fecha;

    public Factura() {
        this.apuestas = new ArrayList();
        fecha = LocalDate.now();
    }

    public void insertarApuesta(Apuesta a) {
        apuestas.add(a);
    }

    public double getTotalApostado() {
        double total = 0;
        for (int i = 0; i < apuestas.size(); i++) {
            total += apuestas.get(i).getCantidadApostada();
        }
        return total;
    }

    
    @Override
    public String toString() {
        NumberFormat formato= NumberFormat.getInstance();
        formato.setMaximumFractionDigits(2);
        formato.setMinimumFractionDigits(2);
        String s = "Factura\t\t\t" + "\n\nFecha: " + fecha.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL));
        int i = 0;
        for (Apuesta a : apuestas) {
            i++;
            s += "\n--------------------------";
            s += "\nApuesta numero: " + i + "\n Propietario: " +a.getPropietario() + " "+a.getPropietario().getApellidos()+
                    "\n Cantidad apostada: " + a.getCantidadApostada()+ "\n Cuota: " + a.getCUOTA()+ "\n Tipo de apuesta: " +a.getTipoApuesta()
                    +  "\n Carrera: " +a.getCarrera()+"\n Piloto: " +a.getPiloto()+ "\nEstado de la apuesta: "+ a.getEstado() +"\n\n";
        }

        return s;
    }

}
