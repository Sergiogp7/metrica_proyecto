/*
 * author: clara
 * Comparador que compara por el numero del piloto
 */
package entidades;

import java.util.Comparator;

/**
 *
 * @author clara
 */
public class ComparadorNumeroPiloto implements Comparator<Piloto> {
    @Override
    public int compare (Piloto p1, Piloto p2){
        return p1.getNumero() - p2.getNumero();
    }
}
