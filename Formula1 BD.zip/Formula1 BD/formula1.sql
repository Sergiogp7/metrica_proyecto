-- Usuario admin (esAdmin = 1)
INSERT INTO Usuario (nombreUsuario, password, nombre, apellidos, fechaNacimiento, correo, telefono, saldo, esAdmin) 
VALUES ('adminUser', 'adminPass', 'Admin', 'User', TO_DATE('1980-01-01', 'YYYY-MM-DD'), 'admin@mail.com', '123456789', 1000, 1);

-- Usuario normal (esAdmin = 0)
INSERT INTO Usuario (nombreUsuario, password, nombre, apellidos, fechaNacimiento, correo, telefono, saldo, esAdmin) 
VALUES ('normalUser', 'userPass', 'Normal', 'User', TO_DATE('1995-06-15', 'YYYY-MM-DD'), 'user@mail.com', '987654321', 100, 0);
